package kz.anna.endterm;

import kz.anna.endterm.entity.Client;

public class Main {



}
