package kz.anna.endterm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EndtermApplication {

	public static void main(String[] args) {
		SpringApplication.run(EndtermApplication.class, args);
	}

}
